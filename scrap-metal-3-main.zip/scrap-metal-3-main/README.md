# scrap-metal-3
Infernal Trap is an amazing 3D car driving game in which you enjoy freedom to explore a huge map with many different terrains.
